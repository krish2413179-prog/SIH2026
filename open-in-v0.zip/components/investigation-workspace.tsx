"use client"

import * as React from "react"
import { IconArrowRight, IconCheck, IconCopy, IconDatabase, IconFileText, IconLoader2, IconNetwork, IconPlayerPlay, IconSend, IconShieldCheck, IconWallet } from "@tabler/icons-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const hops = [
  { id: "0x7a91...c42e", label: "Suspect wallet", amount: "12.84 ETH", type: "Wallet", status: "Flagged" },
  { id: "0x44bd...91fa", label: "Hop 1 · Bridge", amount: "12.65 ETH", type: "Contract", status: "Tracing" },
  { id: "0xbc1q...m8k2", label: "Hop 2 · Exchange", amount: "12.42 ETH", type: "VASP", status: "Attributed" },
]

export function InvestigationWorkspace() {
  const [screen, setScreen] = React.useState("intake")
  const [registered, setRegistered] = React.useState(false)
  const [analysisProgress, setAnalysisProgress] = React.useState(0)

  React.useEffect(() => {
    if (screen !== "analysis" || analysisProgress >= 100) return
    const timer = window.setInterval(() => {
      setAnalysisProgress((current) => Math.min(current + 20, 100))
    }, 700)
    return () => window.clearInterval(timer)
  }, [screen, analysisProgress])
  const [dispatched, setDispatched] = React.useState(false)
  const [copied, setCopied] = React.useState(false)

  return (
    <div className="px-4 lg:px-6">
      <Tabs value={screen} onValueChange={setScreen} className="gap-6">
        <TabsList className="grid w-full grid-cols-5 lg:w-fit">
          <TabsTrigger value="intake">Case intake</TabsTrigger>
          <TabsTrigger value="analysis">Analysis progress</TabsTrigger>
          <TabsTrigger value="graph">Transaction graph</TabsTrigger>
          <TabsTrigger value="vasp">VASP intelligence</TabsTrigger>
          <TabsTrigger value="notice">Legal notice</TabsTrigger>
        </TabsList>

        <TabsContent value="intake" className="grid gap-4 lg:grid-cols-[1.25fr_.75fr]">
          <Card>
            <CardHeader><CardTitle>Register a new complaint</CardTitle><CardDescription>Capture the incident details and create a traceable investigation record.</CardDescription></CardHeader>
            <CardContent className="grid gap-5">
              <div className="grid gap-2"><Label htmlFor="case">Case reference</Label><Input id="case" defaultValue="LEA-2026-0418" /></div>
              <div className="grid gap-2"><Label htmlFor="wallet">Suspect wallet address</Label><Input id="wallet" defaultValue="0x7a91...c42e" /></div>
              <div className="grid gap-2"><Label htmlFor="chain">Blockchain network</Label><Input id="chain" defaultValue="Ethereum" /></div>
              <Button onClick={() => { setRegistered(true); setAnalysisProgress(0); setScreen("analysis") }}>{registered ? <><IconCheck /> Case registered</> : <>Register complaint <IconArrowRight /></>}</Button>
            </CardContent>
          </Card>
          <div className="grid gap-4">
            <Card><CardHeader><CardTitle>Evidence readiness</CardTitle><CardDescription>Required fields for a defensible trace.</CardDescription></CardHeader><CardContent className="grid gap-3"><div className="flex items-center gap-2 text-sm"><IconCheck className="text-primary" /> Wallet address captured</div><div className="flex items-center gap-2 text-sm"><IconCheck className="text-primary" /> Blockchain network verified</div><div className="flex items-center gap-2 text-sm text-muted-foreground"><IconDatabase /> Transaction hash pending</div></CardContent></Card>
            <Card><CardHeader><CardTitle>Case status</CardTitle></CardHeader><CardContent className="flex items-center justify-between"><Badge variant={registered ? "default" : "secondary"}>{registered ? "Ready to trace" : "Draft"}</Badge><span className="text-sm text-muted-foreground">Owner: Inspector Rao</span></CardContent></Card>
          </div>
        </TabsContent>

        <TabsContent value="analysis" className="grid gap-4 lg:grid-cols-[1.25fr_.75fr]">
          <Card>
            <CardHeader className="flex-row items-start justify-between">
              <div><CardTitle>Transaction analysis in progress</CardTitle><CardDescription>LEA-2026-0418 is being enriched across the connected blockchain sources.</CardDescription></div>
              <Badge variant={analysisProgress >= 100 ? "default" : "secondary"}>{analysisProgress >= 100 ? "Complete" : "Running"}</Badge>
            </CardHeader>
            <CardContent className="grid gap-6">
              <div className="grid gap-2"><div className="flex items-center justify-between text-sm"><span>Overall analysis</span><strong>{analysisProgress}%</strong></div><div className="h-2 rounded-full bg-muted"><div className="h-2 rounded-full bg-primary transition-all duration-500" style={{ width: `${analysisProgress}%` }} /></div></div>
              <div className="grid gap-4">
                {[['Ingesting transaction history', analysisProgress >= 20], ['Resolving wallet ownership', analysisProgress >= 40], ['Following bridge and mixer hops', analysisProgress >= 60], ['Matching VASP intelligence', analysisProgress >= 80], ['Preparing graph evidence', analysisProgress >= 100]].map(([label, complete]) => <div key={label as string} className="flex items-center gap-3 text-sm"><span className="flex size-6 items-center justify-center rounded-full bg-muted">{complete ? <IconCheck className="size-4 text-primary" /> : <IconLoader2 className="size-4 animate-spin text-muted-foreground" />}</span><span className={complete ? "" : "text-muted-foreground"}>{label as string}</span><Badge className="ml-auto" variant={complete ? "secondary" : "outline"}>{complete ? "Complete" : "Processing"}</Badge></div>)}
              </div>
              <Button disabled={analysisProgress < 100} onClick={() => setScreen("graph")}>View transaction graph <IconArrowRight /></Button>
            </CardContent>
          </Card>
          <div className="grid gap-4"><Card><CardHeader><CardTitle>Analysis context</CardTitle><CardDescription>Signals currently being reviewed.</CardDescription></CardHeader><CardContent className="grid gap-3 text-sm"><div className="flex justify-between"><span className="text-muted-foreground">Blockchain network</span><strong>12.84 ETH</strong></div><div className="flex justify-between"><span className="text-muted-foreground">Network</span><span>Ethereum</span></div><div className="flex justify-between"><span className="text-muted-foreground">Source wallet</span><span className="font-mono">0x7a91...c42e</span></div></CardContent></Card><Card><CardHeader><CardTitle>Trace engine</CardTitle></CardHeader><CardContent className="flex items-center gap-2 text-sm"><IconNetwork className="text-primary" /> Multi-hop heuristics enabled</CardContent></Card></div>
        </TabsContent>

        <TabsContent value="graph" className="grid gap-4">
          <Card><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Multi-hop transaction trace</CardTitle><CardDescription>Follow the movement of funds across the chain.</CardDescription></div><Button onClick={() => setScreen("vasp")}><IconPlayerPlay /> Run attribution</Button></CardHeader><CardContent><div className="grid gap-3 md:grid-cols-3">{hops.map((hop, index) => <React.Fragment key={hop.id}><Card className="bg-muted/30"><CardHeader className="pb-3"><div className="flex items-center justify-between"><IconWallet className="size-5 text-muted-foreground" /><Badge variant={hop.status === "Flagged" ? "destructive" : "secondary"}>{hop.status}</Badge></div><CardTitle className="text-base">{hop.label}</CardTitle><CardDescription className="font-mono text-xs">{hop.id}</CardDescription></CardHeader><CardContent><p className="text-lg font-semibold">{hop.amount}</p><p className="text-xs text-muted-foreground">{hop.type}</p></CardContent></Card>{index < hops.length - 1 && <IconArrowRight className="m-auto hidden md:block" />}</React.Fragment>)}</div><Separator className="my-6" /><div className="flex flex-wrap items-center gap-2 text-sm"><Badge>Ethereum</Badge><span className="text-muted-foreground">Trace confidence</span><strong>96.4%</strong><span className="text-muted-foreground">·</span><span className="text-muted-foreground">Last block 22,481,930</span></div></CardContent></Card>
          <Card><CardHeader><CardTitle>Trace events</CardTitle></CardHeader><CardContent><Table><TableHeader><TableRow><TableHead>Timestamp</TableHead><TableHead>Event</TableHead><TableHead>Value</TableHead><TableHead>Status</TableHead></TableRow></TableHeader><TableBody>{[["18 Apr · 09:41", "Funds received", "12.84 ETH", "Flagged"],["18 Apr · 09:47", "Bridge interaction", "12.65 ETH", "Reviewed"],["18 Apr · 10:02", "Exchange deposit", "12.42 ETH", "Attributed"]].map(row => <TableRow key={row[0]}>{row.map((cell, i) => <TableCell key={cell}>{i === 3 ? <Badge variant="secondary">{cell}</Badge> : cell}</TableCell>)}</TableRow>)}</TableBody></Table></CardContent></Card>
        </TabsContent>

        <TabsContent value="vasp" className="grid gap-4 lg:grid-cols-[1fr_.8fr]">
          <Card><CardHeader><CardTitle>VASP attribution</CardTitle><CardDescription>Exchange intelligence connected to the traced destination.</CardDescription></CardHeader><CardContent className="grid gap-5"><div className="flex items-start gap-4"><div className="rounded-lg bg-muted p-3"><IconShieldCheck className="size-6" /></div><div><p className="font-semibold">CoinSwitch Kuber</p><p className="text-sm text-muted-foreground">India · Registered virtual asset service provider</p></div><Badge className="ml-auto">96% match</Badge></div><Separator /><div className="grid gap-3 text-sm"><div className="flex justify-between"><span className="text-muted-foreground">Destination wallet</span><span className="font-mono">bc1q...m8k2</span></div><div className="flex justify-between"><span className="text-muted-foreground">Compliance contact</span><span>compliance@vasp.example</span></div><div className="flex justify-between"><span className="text-muted-foreground">Evidence package</span><Badge variant="secondary">Ready</Badge></div></div><Button onClick={() => setScreen("notice")}><IconFileText /> Prepare legal notice</Button></CardContent></Card>
          <Card><CardHeader><CardTitle>Attribution signals</CardTitle></CardHeader><CardContent className="grid gap-4"><div><div className="mb-2 flex justify-between text-sm"><span>Address clustering</span><strong>98%</strong></div><div className="h-2 rounded-full bg-muted"><div className="h-2 w-[98%] rounded-full bg-primary" /></div></div><div><div className="mb-2 flex justify-between text-sm"><span>Behavioral match</span><strong>94%</strong></div><div className="h-2 rounded-full bg-muted"><div className="h-2 w-[94%] rounded-full bg-primary" /></div></div><div><div className="mb-2 flex justify-between text-sm"><span>Jurisdiction confidence</span><strong>91%</strong></div><div className="h-2 rounded-full bg-muted"><div className="h-2 w-[91%] rounded-full bg-primary" /></div></div></CardContent></Card>
        </TabsContent>

        <TabsContent value="notice" className="grid gap-4 lg:grid-cols-[1fr_.8fr]"><Card><CardHeader><CardTitle>Dispatch preservation notice</CardTitle><CardDescription>Review the request before sending it to the VASP compliance team.</CardDescription></CardHeader><CardContent className="grid gap-4"><div className="rounded-lg border bg-muted/30 p-4 text-sm leading-6"><p className="font-semibold">Subject: Urgent preservation request · LEA-2026-0418</p><p className="mt-3">Please preserve records associated with destination wallet <span className="font-mono">bc1q...m8k2</span> and the related transaction trail totaling 12.84 ETH.</p></div><Button onClick={() => setDispatched(true)}>{dispatched ? <><IconCheck /> Notice dispatched</> : <><IconSend /> Dispatch notice</>}</Button></CardContent></Card><Card><CardHeader><CardTitle>Notice checklist</CardTitle></CardHeader><CardContent className="grid gap-3 text-sm"><div className="flex gap-2"><IconCheck className="text-primary" /> Jurisdiction and authority attached</div><div className="flex gap-2"><IconCheck className="text-primary" /> Transaction evidence package attached</div><div className="flex gap-2"><IconCheck className="text-primary" /> Preservation scope defined</div><Button variant="outline" onClick={() => { setCopied(true); window.setTimeout(() => setCopied(false), 1500) }}><IconCopy /> {copied ? "Copied reference" : "Copy case reference"}</Button></CardContent></Card></TabsContent>
      </Tabs>
    </div>
  )
}

export default InvestigationWorkspace
